This folder contains wrapup reports for projects from p5.js related [Google Summer of Code](https://summerofcode.withgoogle.com/organizations/4915113891463168/) projects, [Processing Fellowships](https://processingfoundation.org/fellowships), and others.


*Note for contributors: Embedded images and media are welcome. Please host these files externally rather than placing in this repo to avoid adding growing the repository filesize too much.*

### Google Summer of Code 2021
* [Adding Alt Text to the p5.js Website](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/katiejliu_gsoc_2021.md) by Katie Liu, 2021
* [Adding to p5.js Friendly Error System](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/shantanuKaushik_gsoc_2021.md) by Shantanu Kaushik, 2021
* [Activism Through Storytelling with Code](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/nikiito_gsoc_2021.md) by Niki Ito, 2021
* [Addon Library Development - p5.teach.js](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/aditya_gsoc_2021.md) by Aditya Siddheshwar, 2021
* [Internationalization(i18n) and Deployment of p5.js website](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/sanjay_singh_rajpoot_gsoc2020.md) by Sanjay Singh Rajpoot, 2021
* [Improving the p5.xr Library Through Artistic Examples](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/anaisgonzalez_gsoc_2021.md) by Anais Gonzalez, 2021
* [Korean Translations and Website Redesign Proposal](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/josephhong_gsoc_2021.md) by [Joseph Hong](github.com/jhongover9000), 2021
* [Improve Test Coverage in p5.Sound library](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/sai_bhushan_gsoc_2021.md) by [Sai Bhushan](https://github.com/satyasaibhushan), 2021

### Google Summer of Code 2020
* [p5.js accessibility and canvas descriptions](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/luismn_gsoc_2020.md) by Luis Morales-Navarro, 2020
* [p5.js Web Editor Mobile UI](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/ghalestrilo_gsoc_2020.md) by [ghales](https://github.com/ghalestrilo), 2020
* [Extending the p5.js Friendly Error System](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/akshaypadte_gsoc_2020.md) by Akshay Padte, 2020
* [Increasing the Organization and Scope of the p5.js Showcase](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/connieliu_gsoc_2020.md) by Connie Liu, 2020
* [p5 for 50+ teaching](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/inhwayeom_gsoc_2020.md) by Inhwa Yeom, 2020
* [i18n improvements and Italian translation](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/yukienomiya_gsoc_2020.md) by Yukie Nomiya, 2020


### Google Summer of Code 2019
* [Search Bar for Sketches in the p5.js Web Editor](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/rachellim_gsoc_2019.md) by Rachel Lim, 2019
* [Improving WebGL functionality of p5.js](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/sanket_gsoc_2019.md) by [Sanket Singh](https://github.com/sanketsingh24), 2019
* [Improve p5.js unit tests](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/urvashi_gsoc_2019.md) by [Urvashi](https://github.com/ihsavru), 2019
* [Stabilizing and improving p5.xr](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/vedhant_gsoc_2019.md) by [Vedhant Agarwal](https://github.com/vedhant), 2019
* [AudioWorklet Support in p5.js-sound](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/orenshoham_gsoc_2019.md) by Oren Shoham, 2019
* [Code Slang](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/xu_gsoc_2019.md) by Jenna Xu, 2019
* [p5.touchgui](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/L05_GSOC_2019.md) by [Carlos L05 Garcia](https://github.com/L05), 2019 
* [Curating Community Creativity for p5.js 1.0](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/ashleykang_gsoc2019.md) by Ashley Kang, 2019
* [Math in Motion](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/acheng_ogarcia_gsoc_2019.md) by Alexandra Cheng and Oskar Garcia, 2019

### Processing Foundation Fellowships 2018
* [A p5.js Dissection Manual](https://medium.com/processing-foundation/a-p5-js-dissection-manual-38959ff8522e) by Vijith Assar, 2018
* [Chinese Translation for p5.js and preparing a future of more translations](https://medium.com/processing-foundation/chinese-translation-for-p5-js-and-preparing-a-future-of-more-translations-b56843ea096e), [p5.js 的中文翻译 — 为支持更多种语言翻译做准备](https://medium.com/processing-foundation/p5-js-%E7%9A%84%E4%B8%AD%E6%96%87%E7%BF%BB%E8%AF%91-%E4%B8%BA%E6%94%AF%E6%8C%81%E6%9B%B4%E5%A4%9A%E7%A7%8D%E8%AF%AD%E8%A8%80%E7%BF%BB%E8%AF%91%E5%81%9A%E5%87%86%E5%A4%87-a0fa94da770f) by Kenneth Lim, 2018
* [Making p5.js Accessible](https://medium.com/processing-foundation/making-p5-js-accessible-e2ce366e05a0) by Luis Morales-Navarro and Mathura Govindarajan, 2018
* [Introducing the 2018 Processing Foundation Fellows](https://medium.com/processing-foundation/introducing-the-2018-processing-foundation-fellows-a16ae4e87f80)

### Google Summer of Code 2018

* [A Platform for Algorithmic Composition on p5.js-sound](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/junshern_gsoc_2018.md) by Chan Jun Shern, 2018
* [New JavaScript console in p5.js web editor](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/liang_gsoc_2018.md) by Liang Tang, 2018
* [Updates to WebGL Mode](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/aidannelson_gsoc_2018.md) by Aidan Nelson, 2018
* [Implementing missing primitives in p5.js WebGL mode](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/adilrabbani_gsoc_2018.md) by Adil Rabbani, 2018
* [Dynamic Learning, a collaborative platform for teachers and creative coders](
https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/jithinks_gsoc_2018.md) by Jithin KS, 2018
* [Updating hello.p5js.org](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/elginmclaren_gsoc_2018.md) by Elgin-Skye McLaren, 2018
* [Improvements to existing I/O Methods of p5.js](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/tanvi_gsoc_2018.md) by Tanvi Kumar, 2018

### Processing Foundation Fellowships 2017
* [p5 Accessibility](https://medium.com/processing-foundation/p5-accessibility-115d84535fa8) by Claire Kearney-Volpe, 2017
* [A p5.js Web Editor for All](https://medium.com/processing-foundation/a-p5-js-web-editor-for-all-64aaa3f9d767) by Cassie Tarakajian, 2017
* [Community and Code](https://medium.com/processing-foundation/community-and-code-882b00e6ee32) by Saskia Freeke, 2017
* [¡Manos a la obra! Empecemos. (Creative Coding in p5.js)](https://medium.com/processing-foundation/manos-a-la-obra-empecemos-creative-coding-in-p5-js-a2bfe3e059ce) by DIY Girls, Sylvia Aguiñaga (Director of Curriculum) and Vanessa Landes (Program Leader), 2017
* [Features and Fixes in the p5.js Editor](https://medium.com/processing-foundation/features-and-fixes-in-the-p5-js-editor-722e4b56495e) by Andrew Nicolaou, 2017
* [Everyone Can Code: A creative coding curriculum for students with low computer literacy](https://medium.com/processing-foundation/anyone-can-code-a-creative-coding-curriculum-for-students-with-low-computer-literacy-69e121149abc) by Niklas Peters, 2017
* [Creative Coding with p5.js for Prisons in Washington State](https://medium.com/processing-foundation/creative-coding-with-p5-js-for-prisons-in-washington-state-3bd1d342d769) by Susan Evans, 2017
* [Announcing our 2017 Processing Foundation Fellows](https://medium.com/processing-foundation/announcing-our-2017-processing-foundation-fellows-8b9e7c8bd2f)

### Google Summer of Code 2017 ([archive](https://summerofcode.withgoogle.com/archive/2017/organizations/5256745899261952/))

* [Processing Foundation: GSOC Grand Wrap-Up Post](https://medium.com/processing-foundation/2017-google-summer-of-code-grand-wrap-up-post-16680b1438db)
* [Improving Developer Operations](https://github.com/processing/p5.js/blob/main/contributor_docs/project_wrapups/sakshamsaxena_gsoc_2017.md) by Saksham Saxena, 2017
* [Maps, Maps, Maps!](https://medium.com/processing-foundation/maps-maps-maps-f0914218c87b) by Cristobal Valenzuela, 2017
* [Friendly Error System for p5.js](https://medium.com/processing-foundation/2017-marks-the-processing-foundations-sixth-year-participating-in-google-summer-of-code-d365f62fc463) by A. Mira Chung, 2017
* [Processing Foundation: Our Summer of Code Has Begun!](https://medium.com/processing-foundation/our-summer-of-code-has-begun-dffc1bbddb7c)
